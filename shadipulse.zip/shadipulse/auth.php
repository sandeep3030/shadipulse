<?php
// auth.php - Authentication check for protected pages

// Check if session is started
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// If user is not logged in, redirect to login page
if (!isset($_SESSION['user_id'])) {
    header('Location: index.php');
    exit;
}

// Optional: Check if user is host or admin (for host pages)
function requireHost() {
    if ($_SESSION['role'] !== 'host' && $_SESSION['role'] !== 'admin') {
        header('Location: ../index.php');
        exit;
    }
}

// Optional: Check if user is admin only
function requireAdmin() {
    if ($_SESSION['role'] !== 'admin') {
        header('Location: ../index.php');
        exit;
    }
}
?>