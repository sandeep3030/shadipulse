<?php
require_once '../config.php';
require_once '../auth.php';

// Only super admin can access this
if (!isAdmin()) {
    header('Location: ../index.php');
    exit;
}

// Handle add new admin/host
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['add_user'])) {
    $email = $_POST['email'] ?? '';
    $full_name = $_POST['full_name'] ?? '';
    $role = $_POST['role'] ?? 'host';
    $password = $_POST['password'] ?? '';
    
    if (!empty($email) && !empty($password)) {
        $hash = password_hash($password, PASSWORD_DEFAULT);
        $stmt = $conn->prepare("INSERT INTO users (email, password_hash, full_name, role) VALUES (?, ?, ?, ?)");
        $stmt->bind_param("ssss", $email, $hash, $full_name, $role);
        $stmt->execute();
    }
}

// Handle delete user
if (isset($_GET['delete'])) {
    $id = (int)$_GET['delete'];
    if ($id != $_SESSION['user_id']) { // Prevent self-deletion
        $conn->query("DELETE FROM users WHERE id = $id");
    }
    header("Location: manage_admins.php");
    exit;
}

// Get all users
$users = $conn->query("SELECT * FROM users ORDER BY role, created_at DESC");
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Manage Users - ShadiPulse Admin</title>
    <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css" rel="stylesheet">
</head>
<body class="bg-gray-100">
    <div class="container mx-auto p-6">
        <div class="bg-white rounded-lg shadow-md p-6 mb-6">
            <h1 class="text-2xl font-bold text-pink-600">👥 Manage Users</h1>
            <p class="text-gray-600">Add or remove hosts and admins</p>
        </div>
        
        <!-- Add User Form -->
        <div class="bg-white rounded-lg shadow-md p-6 mb-6">
            <h2 class="text-xl font-bold mb-4">➕ Add New User</h2>
            <form method="POST" class="grid md:grid-cols-4 gap-4">
                <input type="text" name="full_name" placeholder="Full Name" required 
                       class="px-3 py-2 border rounded-lg">
                <input type="email" name="email" placeholder="Email" required 
                       class="px-3 py-2 border rounded-lg">
                <input type="password" name="password" placeholder="Password" required 
                       class="px-3 py-2 border rounded-lg">
                <select name="role" class="px-3 py-2 border rounded-lg">
                    <option value="host">🏨 Host (Wedding Organizer)</option>
                    <option value="admin">👑 Admin (SaaS Owner)</option>
                </select>
                <button type="submit" name="add_user" class="bg-green-500 text-white px-4 py-2 rounded hover:bg-green-600">
                    Add User
                </button>
            </form>
        </div>
        
        <!-- Users List -->
        <div class="bg-white rounded-lg shadow-md p-6">
            <h2 class="text-xl font-bold mb-4">📋 All Users</h2>
            <div class="overflow-x-auto">
                <table class="w-full">
                    <thead class="bg-gray-100">
                        <tr>
                            <th class="p-2 text-left">ID</th>
                            <th class="p-2 text-left">Name</th>
                            <th class="p-2 text-left">Email</th>
                            <th class="p-2 text-left">Role</th>
                            <th class="p-2 text-left">Created</th>
                            <th class="p-2 text-left">Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php while ($user = $users->fetch_assoc()): ?>
                        <tr class="border-t">
                            <td class="p-2"><?php echo $user['id']; ?> </td>
                            <td class="p-2"><?php echo htmlspecialchars($user['full_name']); ?> </td>
                            <td class="p-2"><?php echo $user['email']; ?> </td>
                            <td class="p-2">
                                <?php if ($user['role'] == 'admin'): ?>
                                    <span class="bg-purple-100 text-purple-800 px-2 py-1 rounded text-xs">Admin</span>
                                <?php else: ?>
                                    <span class="bg-blue-100 text-blue-800 px-2 py-1 rounded text-xs">Host</span>
                                <?php endif; ?>
                            </td>
                            <td class="p-2"><?php echo date('M d, Y', strtotime($user['created_at'])); ?> </td>
                            <td class="p-2">
                                <?php if ($user['id'] != $_SESSION['user_id']): ?>
                                    <a href="?delete=<?php echo $user['id']; ?>" 
                                       onclick="return confirm('Delete this user?')"
                                       class="bg-red-500 text-white px-2 py-1 rounded text-sm hover:bg-red-600">
                                        Delete
                                    </a>
                                <?php else: ?>
                                    <span class="text-gray-400 text-sm">Current</span>
                                <?php endif; ?>
                            </td>
                        </tr>
                        <?php endwhile; ?>
                    </tbody>
                </table>
            </div>
        </div>
        
        <div class="mt-6 text-center">
            <a href="dashboard.php" class="text-pink-600 hover:underline">← Back to Dashboard</a>
        </div>
    </div>
</body>
</html>