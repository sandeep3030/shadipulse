<!-- guest/vote.php -->
<?php
require_once '../config.php';
$event_code = $_GET['code'] ?? '';
if (empty($event_code)) {
    die("Invalid event code");
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=yes">
    <title>ShadiPulse - Live Wedding Voting</title>
    <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css" rel="stylesheet">
    <style>
        .vote-btn { transition: all 0.2s ease; }
        .vote-btn:active { transform: scale(0.95); }
        .reaction-emoji { font-size: 2rem; cursor: pointer; transition: transform 0.2s; }
        .reaction-emoji:active { transform: scale(1.2); }
    </style>
</head>
<body class="bg-gradient-to-r from-pink-400 to-red-400 min-h-screen">
    <div class="container mx-auto px-4 py-8 max-w-md">
        <div class="bg-white rounded-2xl shadow-2xl p-6 mb-4">
            <h1 class="text-3xl font-bold text-center text-pink-600 mb-2">🎉 ShadiPulse 🎉</h1>
            <p class="text-center text-gray-600 mb-6">Wedding Moments</p>
            
            <div id="poll-container">
                <div id="question-area" class="text-center mb-6">
                    <h2 id="question-text" class="text-2xl font-bold text-gray-800 mb-4">Loading...</h2>
                    <div id="options-area" class="space-y-3"></div>
                </div>
                
                <div id="results-area" class="hidden mt-6 p-4 bg-gray-100 rounded-xl">
                    <h3 class="font-bold text-lg mb-2">Live Results 📊</h3>
                    <div id="results-chart"></div>
                </div>
                
                <div class="mt-8 text-center">
                    <p class="text-gray-600 mb-3">Express your feelings 💝</p>
                    <div id="reactions" class="flex justify-around">
                        <span class="reaction-emoji" data-reaction="❤️">❤️</span>
                        <span class="reaction-emoji" data-reaction="😂">😂</span>
                        <span class="reaction-emoji" data-reaction="🔥">🔥</span>
                        <span class="reaction-emoji" data-reaction="🎉">🎉</span>
                        <span class="reaction-emoji" data-reaction="😍">😍</span>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <script>
        const eventCode = '<?php echo $event_code; ?>';
        let deviceId = localStorage.getItem('device_id');
        if (!deviceId) {
            deviceId = 'dev_' + Math.random().toString(36).substr(2, 16) + '_' + Date.now();
            localStorage.setItem('device_id', deviceId);
        }
        
        let currentQuestionId = null;
        let hasVoted = false;
        let resultsChart = null;
        let pollInterval = null;
        
        async function fetchCurrentQuestion() {
            try {
                const response = await fetch(`../api/guest_api.php?action=get_question&event_code=${eventCode}&device_id=${deviceId}`);
                const data = await response.json();
                
                if (data.success && data.question) {
                    currentQuestionId = data.question.id;
                    hasVoted = data.has_voted;
                    document.getElementById('question-text').innerText = data.question.text;
                    
                    let optionsHtml = '';
                    if (data.question.type === 'yesno') {
                        optionsHtml = `
                            <button class="vote-btn w-full bg-green-500 text-white py-3 rounded-xl text-xl font-bold" data-value="yes">✅ Yes</button>
                            <button class="vote-btn w-full bg-red-500 text-white py-3 rounded-xl text-xl font-bold" data-value="no">❌ No</button>
                        `;
                    } else {
                        const options = JSON.parse(data.question.options);
                        options.forEach(opt => {
                            optionsHtml += `<button class="vote-btn w-full bg-purple-500 text-white py-3 rounded-xl text-lg font-semibold" data-value="${opt.value}">${opt.label}</button>`;
                        });
                    }
                    
                    document.getElementById('options-area').innerHTML = optionsHtml;
                    
                    if (!hasVoted) {
                        document.querySelectorAll('.vote-btn').forEach(btn => {
                            btn.addEventListener('click', () => submitVote(btn.dataset.value));
                        });
                        document.getElementById('results-area').classList.add('hidden');
                    } else {
                        document.getElementById('options-area').innerHTML = '<p class="text-center text-green-600 font-bold">✓ You have already voted! 🎉</p>';
                        document.getElementById('results-area').classList.remove('hidden');
                        fetchResults();
                    }
                } else if (data.message) {
                    document.getElementById('question-text').innerText = data.message;
                    document.getElementById('options-area').innerHTML = '<p class="text-center text-gray-500">⏳ Waiting for host to start the poll...</p>';
                }
            } catch (error) {
                console.error('Error:', error);
            }
        }
        
        async function submitVote(value) {
            if (hasVoted) return;
            
            const formData = new FormData();
            formData.append('action', 'submit_vote');
            formData.append('event_code', eventCode);
            formData.append('question_id', currentQuestionId);
            formData.append('option_value', value);
            formData.append('device_id', deviceId);
            
            try {
                const response = await fetch('../api/guest_api.php', {
                    method: 'POST',
                    body: formData
                });
                const data = await response.json();
                
                if (data.success) {
                    hasVoted = true;
                    document.getElementById('options-area').innerHTML = '<p class="text-center text-green-600 font-bold">✓ Thank you for voting! 🎊</p>';
                    document.getElementById('results-area').classList.remove('hidden');
                    fetchResults();
                    
                    // Confetti effect
                    confetti({ particleCount: 100, spread: 70, origin: { y: 0.6 } });
                } else {
                    alert(data.message || 'Error submitting vote');
                }
            } catch (error) {
                console.error('Error:', error);
            }
        }
        
        async function fetchResults() {
            try {
                const response = await fetch(`../api/guest_api.php?action=get_results&event_code=${eventCode}&question_id=${currentQuestionId}`);
                const data = await response.json();
                
                if (data.success && data.results) {
                    updateChart(data.results);
                }
            } catch (error) {
                console.error('Error:', error);
            }
        }
        
        function updateChart(results) {
            const labels = results.map(r => r.label);
            const counts = results.map(r => r.count);
            
            if (resultsChart) {
                resultsChart.destroy();
            }
            
            const ctx = document.createElement('canvas');
            document.getElementById('results-chart').innerHTML = '';
            document.getElementById('results-chart').appendChild(ctx);
            
            resultsChart = new Chart(ctx, {
                type: 'bar',
                data: { labels: labels, datasets: [{ label: 'Votes', data: counts, backgroundColor: '#f472b6' }] },
                options: { responsive: true, maintainAspectRatio: true }
            });
        }
        
        // Emoji reactions
        document.querySelectorAll('.reaction-emoji').forEach(emoji => {
            emoji.addEventListener('click', async () => {
                const reaction = emoji.dataset.reaction;
                const formData = new FormData();
                formData.append('action', 'submit_reaction');
                formData.append('event_code', eventCode);
                formData.append('reaction', reaction);
                formData.append('device_id', deviceId);
                
                await fetch('../api/guest_api.php', { method: 'POST', body: formData });
                
                // Visual feedback
                emoji.style.transform = 'scale(1.3)';
                setTimeout(() => { emoji.style.transform = 'scale(1)'; }, 200);
            });
        });
        
        fetchCurrentQuestion();
        pollInterval = setInterval(() => {
            if (hasVoted) fetchResults();
            else fetchCurrentQuestion();
        }, 3000);
        
        // Confetti library
        const script = document.createElement('script');
        script.src = 'https://cdn.jsdelivr.net/npm/canvas-confetti@1';
        document.head.appendChild(script);
    </script>
</body>
</html>