<?php
define('DB_HOST', 'sdb-80.hosting.stackcp.net');
define('DB_USER', 'sandeep-6e36');
define('DB_PASS', 'san@123deep');
define('DB_NAME', 'shadipulse-3530383528d3');

$conn = new mysqli(DB_HOST, DB_USER, DB_PASS, DB_NAME);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

session_start();

function isLoggedIn() {
    return isset($_SESSION['user_id']);
}

function isAdmin() {
    return isset($_SESSION['role']) && $_SESSION['role'] === 'admin';
}

function isHost() {
    return isset($_SESSION['role']) && $_SESSION['role'] === 'host';
}
?>