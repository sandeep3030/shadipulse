<?php
// api/host_api.php
require_once '../config.php';
require_once '../auth.php';
header('Content-Type: application/json');

if (!isLoggedIn()) {
    echo json_encode(['success' => false, 'message' => 'Unauthorized']);
    exit;
}

$action = $_GET['action'] ?? $_POST['action'] ?? '';

switch($action) {
    case 'list_events':
        $stmt = $conn->prepare("SELECT * FROM events WHERE created_by = ? ORDER BY created_at DESC");
        $stmt->bind_param("i", $_SESSION['user_id']);
        $stmt->execute();
        $result = $stmt->get_result();
        $events = $result->fetch_all(MYSQLI_ASSOC);
        echo json_encode(['success' => true, 'data' => $events]);
        break;
        
    case 'create_event':
        $name = $_POST['name'] ?? '';
        $event_date = $_POST['event_date'] ?? '';
        $event_code = strtoupper(substr(md5(uniqid()), 0, 8));
        
        $stmt = $conn->prepare("INSERT INTO events (event_code, name, event_date, created_by, status) VALUES (?, ?, ?, ?, 'upcoming')");
        $stmt->bind_param("sssi", $event_code, $name, $event_date, $_SESSION['user_id']);
        
        if ($stmt->execute()) {
            echo json_encode(['success' => true, 'event_id' => $stmt->insert_id, 'event_code' => $event_code]);
        } else {
            echo json_encode(['success' => false, 'message' => 'Error creating event']);
        }
        break;
        
    case 'add_question':
        $event_id = $_POST['event_id'] ?? 0;
        $text = $_POST['text'] ?? '';
        $type = $_POST['type'] ?? 'mcq';
        $options = $_POST['options'] ?? '[]';
        
        $stmt = $conn->prepare("INSERT INTO questions (event_id, question_text, question_type, options_json) VALUES (?, ?, ?, ?)");
        $stmt->bind_param("isss", $event_id, $text, $type, $options);
        
        if ($stmt->execute()) {
            echo json_encode(['success' => true, 'question_id' => $stmt->insert_id]);
        } else {
            echo json_encode(['success' => false]);
        }
        break;
        
    case 'start_poll':
        $event_id = $_POST['event_id'] ?? 0;
        $question_id = $_POST['question_id'] ?? 0;
        
        $stmt = $conn->prepare("UPDATE events SET current_question_id = ?, poll_active = 1 WHERE id = ? AND created_by = ?");
        $stmt->bind_param("iii", $question_id, $event_id, $_SESSION['user_id']);
        
        if ($stmt->execute()) {
            echo json_encode(['success' => true]);
        } else {
            echo json_encode(['success' => false]);
        }
        break;
        
    case 'stop_poll':
        $event_id = $_POST['event_id'] ?? 0;
        
        $stmt = $conn->prepare("UPDATE events SET poll_active = 0 WHERE id = ? AND created_by = ?");
        $stmt->bind_param("ii", $event_id, $_SESSION['user_id']);
        
        echo json_encode(['success' => $stmt->execute()]);
        break;
        
    case 'get_event_questions':
        $event_id = $_GET['event_id'] ?? 0;
        
        $stmt = $conn->prepare("SELECT * FROM questions WHERE event_id = ? AND is_active = 1 ORDER BY order_index");
        $stmt->bind_param("i", $event_id);
        $stmt->execute();
        $result = $stmt->get_result();
        $questions = $result->fetch_all(MYSQLI_ASSOC);
        
        echo json_encode(['success' => true, 'questions' => $questions]);
        break;
        
    case 'get_stats':
        $event_id = $_GET['event_id'] ?? 0;
        
        $stmt = $conn->prepare("SELECT COUNT(DISTINCT device_id) as participants FROM votes WHERE event_id = ?");
        $stmt->bind_param("i", $event_id);
        $stmt->execute();
        $participants = $stmt->get_result()->fetch_assoc()['participants'];
        
        $stmt = $conn->prepare("SELECT COUNT(*) as total_votes FROM votes WHERE event_id = ?");
        $stmt->bind_param("i", $event_id);
        $stmt->execute();
        $total_votes = $stmt->get_result()->fetch_assoc()['total_votes'];
        
        echo json_encode(['success' => true, 'participants' => $participants, 'total_votes' => $total_votes]);
        break;
}
?>