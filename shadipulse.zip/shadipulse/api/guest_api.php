<?php
// api/guest_api.php
require_once '../config.php';
header('Content-Type: application/json');

$action = $_GET['action'] ?? $_POST['action'] ?? '';

switch($action) {
    case 'get_question':
        $event_code = $_GET['event_code'] ?? '';
        $device_id = $_GET['device_id'] ?? '';
        
        $stmt = $conn->prepare("SELECT id FROM events WHERE event_code = ?");
        $stmt->bind_param("s", $event_code);
        $stmt->execute();
        $result = $stmt->get_result();
        $event = $result->fetch_assoc();
        
        if (!$event) {
            echo json_encode(['success' => false, 'message' => 'Event not found']);
            exit;
        }
        
        $event_id = $event['id'];
        
        // Get current active question
        $stmt = $conn->prepare("SELECT e.current_question_id, e.poll_active FROM events e WHERE e.id = ?");
        $stmt->bind_param("i", $event_id);
        $stmt->execute();
        $eventData = $stmt->get_result()->fetch_assoc();
        
        if (!$eventData['poll_active'] || !$eventData['current_question_id']) {
            echo json_encode(['success' => false, 'message' => 'Poll not active yet']);
            exit;
        }
        
        $stmt = $conn->prepare("SELECT id, question_text as text, question_type as type, options_json as options FROM questions WHERE id = ?");
        $stmt->bind_param("i", $eventData['current_question_id']);
        $stmt->execute();
        $question = $stmt->get_result()->fetch_assoc();
        
        // Check if device already voted
        $stmt = $conn->prepare("SELECT COUNT(*) as voted FROM votes WHERE question_id = ? AND device_id = ?");
        $stmt->bind_param("is", $eventData['current_question_id'], $device_id);
        $stmt->execute();
        $voted = $stmt->get_result()->fetch_assoc()['voted'] > 0;
        
        echo json_encode(['success' => true, 'question' => $question, 'has_voted' => $voted]);
        break;
        
    case 'submit_vote':
        $event_code = $_POST['event_code'] ?? '';
        $question_id = $_POST['question_id'] ?? 0;
        $option_value = $_POST['option_value'] ?? '';
        $device_id = $_POST['device_id'] ?? '';
        
        $stmt = $conn->prepare("SELECT id FROM events WHERE event_code = ?");
        $stmt->bind_param("s", $event_code);
        $stmt->execute();
        $event = $stmt->get_result()->fetch_assoc();
        
        if (!$event) {
            echo json_encode(['success' => false, 'message' => 'Invalid event']);
            exit;
        }
        
        // Check duplicate
        $stmt = $conn->prepare("SELECT COUNT(*) as cnt FROM votes WHERE question_id = ? AND device_id = ?");
        $stmt->bind_param("is", $question_id, $device_id);
        $stmt->execute();
        if ($stmt->get_result()->fetch_assoc()['cnt'] > 0) {
            echo json_encode(['success' => false, 'message' => 'Already voted']);
            exit;
        }
        
        $stmt = $conn->prepare("INSERT INTO votes (event_id, question_id, option_key, device_id) VALUES (?, ?, ?, ?)");
        $stmt->bind_param("iiss", $event['id'], $question_id, $option_value, $device_id);
        
        if ($stmt->execute()) {
            echo json_encode(['success' => true]);
        } else {
            echo json_encode(['success' => false, 'message' => 'Database error']);
        }
        break;
        
    case 'submit_reaction':
        $event_code = $_POST['event_code'] ?? '';
        $reaction = $_POST['reaction'] ?? '';
        $device_id = $_POST['device_id'] ?? '';
        
        $stmt = $conn->prepare("SELECT id FROM events WHERE event_code = ?");
        $stmt->bind_param("s", $event_code);
        $stmt->execute();
        $event = $stmt->get_result()->fetch_assoc();
        
        if ($event) {
            $stmt = $conn->prepare("INSERT INTO reactions (event_id, reaction_type, device_id) VALUES (?, ?, ?)");
            $stmt->bind_param("iss", $event['id'], $reaction, $device_id);
            $stmt->execute();
        }
        echo json_encode(['success' => true]);
        break;
        
    case 'get_results':
        $event_code = $_GET['event_code'] ?? '';
        $question_id = $_GET['question_id'] ?? 0;
        
        $stmt = $conn->prepare("SELECT q.options_json, q.question_type FROM questions q WHERE q.id = ?");
        $stmt->bind_param("i", $question_id);
        $stmt->execute();
        $question = $stmt->get_result()->fetch_assoc();
        
        if (!$question) {
            echo json_encode(['success' => false]);
            exit;
        }
        
        $options = json_decode($question['options_json'], true);
        if ($question['question_type'] == 'yesno') {
            $options = [['value' => 'yes', 'label' => 'Yes'], ['value' => 'no', 'label' => 'No']];
        }
        
        $results = [];
        foreach ($options as $opt) {
            $stmt = $conn->prepare("SELECT COUNT(*) as cnt FROM votes WHERE question_id = ? AND option_key = ?");
            $stmt->bind_param("is", $question_id, $opt['value']);
            $stmt->execute();
            $count = $stmt->get_result()->fetch_assoc()['cnt'];
            $results[] = ['label' => $opt['label'], 'count' => $count];
        }
        
        echo json_encode(['success' => true, 'results' => $results]);
        break;
}
?>