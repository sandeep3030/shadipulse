<?php
require_once '../config.php';
header('Content-Type: application/json');

$event_code = $_GET['event_code'] ?? '';

// Get event ID and current question
$stmt = $conn->prepare("SELECT id, current_question_id, poll_active FROM events WHERE event_code = ?");
$stmt->bind_param("s", $event_code);
$stmt->execute();
$event = $stmt->get_result()->fetch_assoc();

if (!$event) {
    echo json_encode(['success' => false, 'message' => 'Event not found']);
    exit;
}

$response = ['success' => true];

// Get current question details
if ($event['poll_active'] && $event['current_question_id']) {
    $stmt = $conn->prepare("SELECT question_text, question_type, options_json FROM questions WHERE id = ?");
    $stmt->bind_param("i", $event['current_question_id']);
    $stmt->execute();
    $question = $stmt->get_result()->fetch_assoc();
    
    if ($question) {
        $response['question'] = $question['question_text'];
        
        // Parse options
        $options = json_decode($question['options_json'], true);
        if (!$options || $question['question_type'] == 'yesno') {
            $options = [['value' => 'yes', 'label' => 'Yes'], ['value' => 'no', 'label' => 'No']];
        }
        
        // Get vote counts for each option
        $results = [];
        foreach ($options as $opt) {
            $value = is_array($opt) ? $opt['value'] : $opt;
            $label = is_array($opt) ? $opt['label'] : $opt;
            
            $stmt = $conn->prepare("SELECT COUNT(*) as cnt FROM votes WHERE question_id = ? AND option_key = ?");
            $stmt->bind_param("is", $event['current_question_id'], $value);
            $stmt->execute();
            $count = $stmt->get_result()->fetch_assoc()['cnt'];
            $results[] = ['label' => $label, 'count' => (int)$count];
        }
        $response['results'] = $results;
    } else {
        $response['question'] = 'No question found';
        $response['results'] = [];
    }
} else {
    $response['question'] = 'Poll not active';
    $response['results'] = [];
}

// Get total participants (unique devices)
$stmt = $conn->prepare("SELECT COUNT(DISTINCT device_id) as participants FROM votes WHERE event_id = ?");
$stmt->bind_param("i", $event['id']);
$stmt->execute();
$response['total_participants'] = (int)$stmt->get_result()->fetch_assoc()['participants'];

// Get recent reactions
$stmt = $conn->prepare("SELECT reaction_type FROM reactions WHERE event_id = ? ORDER BY id DESC LIMIT 10");
$stmt->bind_param("i", $event['id']);
$stmt->execute();
$response['reactions'] = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);

// Add debug info
$response['debug'] = [
    'event_id' => $event['id'],
    'current_question_id' => $event['current_question_id'],
    'poll_active' => $event['poll_active']
];

echo json_encode($response);
?>