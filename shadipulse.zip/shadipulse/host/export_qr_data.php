<?php
require_once '../config.php';
session_start();

if (!isset($_SESSION['user_id'])) {
    die('Unauthorized');
}

$event_id = $_GET['id'] ?? 0;

header('Content-Type: text/csv');
header('Content-Disposition: attachment; filename="qr_scans_event_' . $event_id . '_' . date('Y-m-d') . '.csv"');

$output = fopen('php://output', 'w');
fputcsv($output, ['Scan ID', 'Scan Token', 'IP Address', 'User Agent', 'Scanned At']);

$result = $conn->query("SELECT id, scan_token, ip_address, user_agent, scanned_at FROM qr_scans WHERE event_id = $event_id ORDER BY scanned_at DESC");

while ($row = $result->fetch_assoc()) {
    fputcsv($output, $row);
}

fclose($output);
exit;
?>