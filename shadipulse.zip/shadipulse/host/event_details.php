<?php
require_once '../auth.php';
require_once '../config.php';
requireHost();

$event_id = $_GET['id'] ?? 0;
if (!$event_id) {
    header('Location: dashboard.php');
    exit;
}

// Get event details
$stmt = $conn->prepare("SELECT * FROM events WHERE id = ? AND created_by = ?");
$stmt->bind_param("ii", $event_id, $_SESSION['user_id']);
$stmt->execute();
$event = $stmt->get_result()->fetch_assoc();

if (!$event) {
    header('Location: dashboard.php');
    exit;
}

// Generate QR code data URL
$guest_url = "https://shadipulse.greetly.in/guest/vote.php?code=" . $event['event_code'];
$qr_code_url = "https://api.qrserver.com/v1/create-qr-code/?size=200x200&data=" . urlencode($guest_url);

// Handle add question
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['add_question'])) {
    $question_text = $_POST['question_text'] ?? '';
    $question_type = $_POST['question_type'] ?? 'mcq';
    $options = [];
    
    if ($question_type == 'mcq') {
        $options_array = explode(',', $_POST['mcq_options'] ?? '');
        foreach ($options_array as $opt) {
            $options[] = ['value' => trim($opt), 'label' => trim($opt)];
        }
    } elseif ($question_type == 'yesno') {
        $options = [['value' => 'yes', 'label' => 'Yes'], ['value' => 'no', 'label' => 'No']];
    }
    
    $options_json = json_encode($options);
    
    $stmt = $conn->prepare("INSERT INTO questions (event_id, question_text, question_type, options_json) VALUES (?, ?, ?, ?)");
    $stmt->bind_param("isss", $event_id, $question_text, $question_type, $options_json);
    $stmt->execute();
    header("Location: event_details.php?id=$event_id");
    exit;
}

// Handle start poll
if (isset($_GET['start_question'])) {
    $question_id = (int)$_GET['start_question'];
    $conn->query("UPDATE events SET current_question_id = $question_id, poll_active = 1 WHERE id = $event_id");
    header("Location: event_details.php?id=$event_id");
    exit;
}

// Handle stop poll
if (isset($_GET['stop_poll'])) {
    $conn->query("UPDATE events SET poll_active = 0 WHERE id = $event_id");
    header("Location: event_details.php?id=$event_id");
    exit;
}

// Handle delete question
if (isset($_GET['delete_question'])) {
    $question_id = (int)$_GET['delete_question'];
    $conn->query("DELETE FROM questions WHERE id = $question_id AND event_id = $event_id");
    header("Location: event_details.php?id=$event_id");
    exit;
}

// Get questions
$questions = $conn->query("SELECT * FROM questions WHERE event_id = $event_id ORDER BY order_index");
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Manage Event - ShadiPulse</title>
    <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css" rel="stylesheet">
    <style>
        @media print {
            .no-print { display: none; }
            .print-only { display: block; }
        }
        .print-only { display: none; }
    </style>
</head>
<body class="bg-gray-100">
    <div class="container mx-auto p-6">
        <!-- Event Details Card -->
        <div class="bg-white rounded-lg shadow-md p-6 mb-6">
            <div class="flex justify-between items-start">
                <div>
                    <h1 class="text-2xl font-bold text-pink-600">📅 <?php echo htmlspecialchars($event['name']); ?></h1>
                    <p class="text-gray-600 mt-1">Event Code: <strong class="text-xl"><?php echo $event['event_code']; ?></strong></p>
                    <p class="text-gray-600">Status: <span class="font-bold <?php echo $event['poll_active'] ? 'text-green-600' : 'text-gray-600'; ?>"><?php echo $event['poll_active'] ? '🟢 Live' : '⚪ Not Active'; ?></span></p>
                </div>
                <div class="text-right">
                    <p class="text-sm text-gray-500">Created: <?php echo date('M d, Y', strtotime($event['created_at'])); ?></p>
                    <p class="text-sm text-gray-500">Event Date: <?php echo date('M d, Y', strtotime($event['event_date'])); ?></p>
                </div>
            </div>
            
            <!-- QR Code Section -->
            <!-- QR Code Section -->
<div class="mt-6 p-4 bg-gray-50 rounded-lg border-2 border-dashed border-gray-300">
    <h3 class="font-bold text-lg mb-3 text-center">📱 Guest Access QR Code</h3>
    <div class="flex flex-col md:flex-row items-center justify-center gap-6">
        <div class="text-center">
            <?php 
            // Use tracking URL instead of direct guest URL
            $tracking_url = "https://shadipulse.greetly.in/qr_redirect.php?code=" . $event['event_code'];
            $qr_code_url = "https://api.qrserver.com/v1/create-qr-code/?size=200x200&data=" . urlencode($tracking_url);
            ?>
            <img src="<?php echo $qr_code_url; ?>" alt="QR Code" class="border rounded-lg shadow-md" style="width: 200px; height: 200px;">
            <p class="text-sm text-gray-600 mt-2">Scan to vote</p>
            <?php if ($event['qr_scan_count'] > 0): ?>
                <p class="text-xs text-green-600 mt-1">📊 <?php echo $event['qr_scan_count']; ?> scans so far</p>
            <?php endif; ?>
        </div>
        <div class="flex-1">
            <p class="text-sm text-gray-700 mb-2"><strong>Tracking URL:</strong><br>
            <code class="text-xs bg-gray-100 p-1 rounded break-all"><?php echo $tracking_url; ?></code></p>
            <div class="flex gap-3 mt-4 flex-wrap">
                <button onclick="window.open('<?php echo $qr_code_url; ?>')" class="bg-blue-500 text-white px-4 py-2 rounded-lg text-sm hover:bg-blue-600 no-print">
                    📥 Download QR
                </button>
                <button onclick="window.print()" class="bg-green-500 text-white px-4 py-2 rounded-lg text-sm hover:bg-green-600 no-print">
                    🖨️ Print QR Code
                </button>
                <button onclick="copyToClipboard('<?php echo $tracking_url; ?>')" class="bg-gray-500 text-white px-4 py-2 rounded-lg text-sm hover:bg-gray-600 no-print">
                    📋 Copy Tracking Link
                </button>
            </div>
        </div>
    </div>
</div>
            
            <div class="mt-4 flex flex-wrap gap-3 no-print">
                <a href="dashboard.php" class="bg-gray-500 text-white px-4 py-2 rounded hover:bg-gray-600">← Back to Dashboard</a>
                <a href="../guest/vote.php?code=<?php echo $event['event_code']; ?>" target="_blank" class="bg-blue-500 text-white px-4 py-2 rounded hover:bg-blue-600">📱 Preview Guest Page</a>
                <a href="../screen/display.php?code=<?php echo $event['event_code']; ?>" target="_blank" class="bg-purple-500 text-white px-4 py-2 rounded hover:bg-purple-600">🖥️ Open Big Screen</a>
                <a href="qr_analytics.php?id=<?php echo $event_id; ?>" class="bg-indigo-500 text-white px-4 py-2 rounded hover:bg-indigo-600">📊 QR Analytics</a>
                <?php if ($event['poll_active']): ?>
                    <a href="?id=<?php echo $event_id; ?>&stop_poll=1" class="bg-red-500 text-white px-4 py-2 rounded hover:bg-red-600" onclick="return confirm('Stop current poll?')">⏹️ Stop Poll</a>
                <?php endif; ?>
            </div>
        </div>
        
        <!-- QR Code Print Section (visible only when printing) -->
        <div class="print-only text-center" style="margin-top: 50px;">
            <h2 style="font-size: 24px;"><?php echo htmlspecialchars($event['name']); ?></h2>
            <p style="font-size: 18px; margin-bottom: 30px;">Scan to vote at our wedding!</p>
            <img src="<?php echo $qr_code_url; ?>" style="width: 300px; height: 300px; margin: 0 auto;">
            <p style="margin-top: 30px; font-size: 16px;"><?php echo $guest_url; ?></p>
        </div>
        
        <!-- Add Question Form -->
        <div class="bg-white rounded-lg shadow-md p-6 mb-6 no-print">
            <h2 class="text-xl font-bold mb-4">➕ Add New Question</h2>
            <form method="POST">
                <div class="mb-3">
                    <label class="block text-gray-700 font-bold mb-1">Question Text</label>
                    <input type="text" name="question_text" placeholder="e.g., Who is the better dancer?" required class="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-pink-500">
                </div>
                <div class="mb-3">
                    <label class="block text-gray-700 font-bold mb-1">Question Type</label>
                    <select name="question_type" id="question_type" class="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-pink-500">
                        <option value="mcq">Multiple Choice (MCQ)</option>
                        <option value="yesno">Yes / No</option>
                    </select>
                </div>
                <div id="mcq_options_div" class="mb-3">
                    <label class="block text-gray-700 font-bold mb-1">Options (comma separated)</label>
                    <input type="text" name="mcq_options" placeholder="e.g., Bride, Groom, Both" class="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-pink-500">
                </div>
                <button type="submit" name="add_question" class="bg-green-500 text-white px-6 py-2 rounded-lg hover:bg-green-600 transition">➕ Add Question</button>
            </form>
        </div>
        
        <!-- Questions List -->
        <div class="bg-white rounded-lg shadow-md p-6">
            <h2 class="text-xl font-bold mb-4">📋 Questions List</h2>
            <?php if ($questions->num_rows == 0): ?>
                <p class="text-gray-500 text-center py-4">No questions yet. Add your first question above!</p>
            <?php else: ?>
                <?php while ($q = $questions->fetch_assoc()): ?>
                    <div class="border rounded-lg p-4 mb-3 <?php echo ($event['current_question_id'] == $q['id'] && $event['poll_active']) ? 'bg-pink-50 border-pink-500' : ''; ?>">
                        <div class="flex justify-between items-start">
                            <div class="flex-1">
                                <p class="font-bold text-lg"><?php echo htmlspecialchars($q['question_text']); ?></p>
                                <p class="text-sm text-gray-600 mt-1">Type: <?php echo strtoupper($q['question_type']); ?></p>
                                <?php if ($event['current_question_id'] == $q['id'] && $event['poll_active']): ?>
                                    <span class="inline-block bg-green-500 text-white text-xs px-2 py-1 rounded mt-2">🔴 LIVE NOW</span>
                                <?php endif; ?>
                            </div>
                            <div class="flex gap-2">
                                <?php if (!$event['poll_active'] || $event['current_question_id'] != $q['id']): ?>
                                    <a href="?id=<?php echo $event_id; ?>&start_question=<?php echo $q['id']; ?>" class="bg-pink-500 text-white px-3 py-1 rounded text-sm hover:bg-pink-600">▶️ Start</a>
                                <?php endif; ?>
                                <a href="?id=<?php echo $event_id; ?>&delete_question=<?php echo $q['id']; ?>" class="bg-red-500 text-white px-3 py-1 rounded text-sm hover:bg-red-600" onclick="return confirm('Delete this question? All votes will be lost.')">🗑️ Delete</a>
                            </div>
                        </div>
                    </div>
                <?php endwhile; ?>
            <?php endif; ?>
        </div>
    </div>
    
    <script>
        document.getElementById('question_type').addEventListener('change', function() {
            var div = document.getElementById('mcq_options_div');
            div.style.display = this.value === 'mcq' ? 'block' : 'none';
        });
        
        function copyToClipboard(text) {
            navigator.clipboard.writeText(text).then(function() {
                alert('Guest link copied to clipboard!');
            });
        }
    </script>
</body>
</html>