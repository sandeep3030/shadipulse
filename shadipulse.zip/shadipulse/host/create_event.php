<?php
require_once '../auth.php';
require_once '../config.php';
requireHost();

$success = '';
$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = $_POST['name'] ?? '';
    $event_date = $_POST['event_date'] ?? '';
    
    if (empty($name) || empty($event_date)) {
        $error = 'Please fill all fields';
    } else {
        // Generate unique event code (8 characters)
        $event_code = strtoupper(substr(md5(uniqid()), 0, 8));
        
        $stmt = $conn->prepare("INSERT INTO events (event_code, name, event_date, created_by, status) VALUES (?, ?, ?, ?, 'upcoming')");
        $stmt->bind_param("sssi", $event_code, $name, $event_date, $_SESSION['user_id']);
        
        if ($stmt->execute()) {
            $event_id = $stmt->insert_id;
            $success = "Event created successfully! Your event code is: <strong>$event_code</strong>";
            // Clear form
            $_POST = array();
        } else {
            $error = "Error creating event: " . $conn->error;
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Create Event - ShadiPulse</title>
    <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css" rel="stylesheet">
</head>
<body class="bg-gray-100">
    <div class="container mx-auto p-6">
        <div class="bg-white rounded-lg shadow-md p-6 max-w-2xl mx-auto">
            <h1 class="text-2xl font-bold mb-6 text-pink-600">🎉 Create New Event</h1>
            
            <?php if ($success): ?>
                <div class="bg-green-100 border border-green-400 text-green-700 px-4 py-3 rounded mb-4">
                    <?php echo $success; ?>
                </div>
            <?php endif; ?>
            
            <?php if ($error): ?>
                <div class="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded mb-4">
                    <?php echo $error; ?>
                </div>
            <?php endif; ?>
            
            <form method="POST">
                <div class="mb-4">
                    <label class="block text-gray-700 font-bold mb-2">Event Name</label>
                    <input type="text" name="name" required 
                           class="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-pink-500"
                           placeholder="e.g., John & Jane Wedding">
                </div>
                
                <div class="mb-6">
                    <label class="block text-gray-700 font-bold mb-2">Event Date</label>
                    <input type="date" name="event_date" required 
                           class="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-pink-500">
                </div>
                
                <div class="flex gap-3">
                    <button type="submit" class="bg-pink-600 text-white px-6 py-2 rounded-lg hover:bg-pink-700 transition">
                        Create Event
                    </button>
                    <a href="dashboard.php" class="bg-gray-500 text-white px-6 py-2 rounded-lg hover:bg-gray-600 transition">
                        Cancel
                    </a>
                </div>
            </form>
        </div>
    </div>
</body>
</html>