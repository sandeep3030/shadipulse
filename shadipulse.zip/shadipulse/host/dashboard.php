<?php
ini_set('display_errors', 1);
error_reporting(E_ALL);
require_once '../config.php';
require_once '../auth.php';
if (!isHost() && !isAdmin()) {
    header('Location: ../index.php');
    exit;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Host Dashboard - ShadiPulse</title>
    <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css" rel="stylesheet">
</head>
<body class="bg-gray-100">
    <nav class="bg-pink-600 text-white p-4 shadow-lg">
        <div class="container mx-auto flex justify-between">
            <h1 class="text-2xl font-bold">🎉 ShadiPulse Host Dashboard</h1>
            <div>
                <span>Welcome, <?php echo $_SESSION['full_name']; ?></span>
                <a href="change_password.php" class="ml-4 bg-yellow-500 text-white px-4 py-2 rounded hover:bg-yellow-600 transition">🔑 Change Password</a>
                <a href="../logout.php" class="ml-2 bg-red-500 px-4 py-2 rounded hover:bg-red-600 transition">Logout</a>
            </div>
        </div>
    </nav>

    <?php include 'includes/admin_menu.php'; ?>
    
    <div class="container mx-auto p-6">
        <div class="bg-white rounded-lg shadow p-6 mb-6">
            <h2 class="text-2xl font-bold mb-4">Quick Actions</h2>
            <a href="create_event.php" class="bg-green-500 text-white px-6 py-3 rounded-lg inline-block">➕ Create New Event</a>
        </div>
        
        <div class="bg-white rounded-lg shadow p-6">
            <h2 class="text-2xl font-bold mb-4">My Events</h2>
            <div id="events-list" class="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
                Loading...
            </div>
        </div>
    </div>
    
    <script>
        async function loadEvents() {
            try {
                const response = await fetch('../api/host_api.php?action=list_events');
                const events = await response.json();
                
                if (events.success) {
                    const container = document.getElementById('events-list');
                    if (events.data.length === 0) {
                        container.innerHTML = '<p class="col-span-3 text-center text-gray-500">No events yet. Create your first event!</p>';
                        return;
                    }
                    
                    container.innerHTML = events.data.map(event => `
                        <div class="border rounded-lg p-4 hover:shadow-lg transition">
                            <h3 class="font-bold text-xl mb-2">${event.name}</h3>
                            <p class="text-gray-600">📅 ${event.event_date}</p>
                            <p class="text-gray-600">🔑 Code: ${event.event_code}</p>
                            <p class="text-sm ${event.status === 'live' ? 'text-green-600' : 'text-gray-500'}">Status: ${event.status}</p>
                            <div class="mt-4 space-y-2">
                                <a href="event_details.php?id=${event.id}" class="block bg-blue-500 text-white text-center px-4 py-2 rounded">Manage Event</a>
                                <a href="../guest/vote.php?code=${event.event_code}" target="_blank" class="block bg-purple-500 text-white text-center px-4 py-2 rounded">Guest Link</a>
                                <a href="../screen/display.php?code=${event.event_code}" target="_blank" class="block bg-pink-500 text-white text-center px-4 py-2 rounded">Big Screen</a>
                            </div>
                        </div>
                    `).join('');
                }
            } catch (error) {
                console.error('Error:', error);
            }
        }
        
        loadEvents();
        setInterval(loadEvents, 5000);
    </script>
</body>
</html>