<?php
require_once '../auth.php';
require_once '../config.php';
requireHost();

$event_id = $_GET['id'] ?? 0;
if (!$event_id) {
    header('Location: dashboard.php');
    exit;
}

// Get event details
$stmt = $conn->prepare("SELECT * FROM events WHERE id = ? AND created_by = ?");
$stmt->bind_param("ii", $event_id, $_SESSION['user_id']);
$stmt->execute();
$event = $stmt->get_result()->fetch_assoc();

if (!$event) {
    header('Location: dashboard.php');
    exit;
}

// Get scan statistics
$scan_stats = $conn->query("
    SELECT 
        COUNT(*) as total_scans,
        COUNT(DISTINCT scan_token) as unique_scans,
        COUNT(DISTINCT ip_address) as unique_ips,
        DATE(scanned_at) as scan_date,
        HOUR(scanned_at) as scan_hour
    FROM qr_scans 
    WHERE event_id = $event_id
");

$total_scans = $conn->query("SELECT COUNT(*) as total FROM qr_scans WHERE event_id = $event_id")->fetch_assoc()['total'];
$unique_scans = $conn->query("SELECT COUNT(DISTINCT scan_token) as unique FROM qr_scans WHERE event_id = $event_id")->fetch_assoc()['unique'];
$unique_ips = $conn->query("SELECT COUNT(DISTINCT ip_address) as unique FROM qr_scans WHERE event_id = $event_id")->fetch_assoc()['unique'];

// Get scans by date
$scans_by_date = $conn->query("
    SELECT DATE(scanned_at) as date, COUNT(*) as count 
    FROM qr_scans 
    WHERE event_id = $event_id 
    GROUP BY DATE(scanned_at) 
    ORDER BY date DESC 
    LIMIT 30
");

// Get recent scans
$recent_scans = $conn->query("
    SELECT * FROM qr_scans 
    WHERE event_id = $event_id 
    ORDER BY scanned_at DESC 
    LIMIT 20
");
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>QR Analytics - <?php echo htmlspecialchars($event['name']); ?></title>
    <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
</head>
<body class="bg-gray-100">
    <div class="container mx-auto p-6">
        <div class="bg-white rounded-lg shadow-md p-6 mb-6">
            <div class="flex justify-between items-center">
                <div>
                    <h1 class="text-2xl font-bold text-pink-600">📊 QR Code Analytics</h1>
                    <p class="text-gray-600">Event: <?php echo htmlspecialchars($event['name']); ?></p>
                    <p class="text-gray-500 text-sm">Event Code: <?php echo $event['event_code']; ?></p>
                </div>
                <a href="event_details.php?id=<?php echo $event_id; ?>" class="bg-gray-500 text-white px-4 py-2 rounded hover:bg-gray-600">← Back to Event</a>
            </div>
        </div>
        
        <!-- Stats Cards -->
        <div class="grid md:grid-cols-4 gap-6 mb-6">
            <div class="bg-white rounded-lg shadow-md p-6 text-center">
                <div class="text-3xl font-bold text-pink-600"><?php echo $total_scans; ?></div>
                <div class="text-gray-600">Total QR Scans</div>
            </div>
            <div class="bg-white rounded-lg shadow-md p-6 text-center">
                <div class="text-3xl font-bold text-blue-600"><?php echo $unique_scans; ?></div>
                <div class="text-gray-600">Unique Devices</div>
                <div class="text-xs text-gray-400">(by scan token)</div>
            </div>
            <div class="bg-white rounded-lg shadow-md p-6 text-center">
                <div class="text-3xl font-bold text-green-600"><?php echo $unique_ips; ?></div>
                <div class="text-gray-600">Unique IP Addresses</div>
            </div>
            <div class="bg-white rounded-lg shadow-md p-6 text-center">
                <div class="text-3xl font-bold text-purple-600"><?php echo $event['qr_scan_count']; ?></div>
                <div class="text-gray-600">Lifetime Scans</div>
            </div>
        </div>
        
        <!-- Charts -->
        <div class="grid md:grid-cols-2 gap-6 mb-6">
            <div class="bg-white rounded-lg shadow-md p-6">
                <h3 class="font-bold text-lg mb-4">📈 Scans Over Time</h3>
                <canvas id="scansChart" height="200"></canvas>
            </div>
            <div class="bg-white rounded-lg shadow-md p-6">
                <h3 class="font-bold text-lg mb-4">⏰ Scans by Hour</h3>
                <canvas id="hourlyChart" height="200"></canvas>
            </div>
        </div>
        
        <!-- Recent Scans Table -->
        <div class="bg-white rounded-lg shadow-md p-6">
            <h3 class="font-bold text-lg mb-4">🕐 Recent QR Scans</h3>
            <div class="overflow-x-auto">
                <table class="w-full text-sm">
                    <thead class="bg-gray-100">
                        <tr>
                            <th class="p-2 text-left">Time</th>
                            <th class="p-2 text-left">IP Address</th>
                            <th class="p-2 text-left">Device</th>
                            <th class="p-2 text-left">Scan Token</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php while ($scan = $recent_scans->fetch_assoc()): ?>
                        <tr class="border-t">
                            <td class="p-2"><?php echo date('M d, H:i:s', strtotime($scan['scanned_at'])); ?></td>
                            <td class="p-2"><?php echo $scan['ip_address']; ?></td>
                            <td class="p-2 text-xs truncate max-w-xs"><?php echo substr($scan['user_agent'], 0, 50); ?>...</td>
                            <td class="p-2 text-xs"><?php echo substr($scan['scan_token'], 0, 16); ?>...</td>
                        </tr>
                        <?php endwhile; ?>
                        <?php if ($recent_scans->num_rows == 0): ?>
                        <tr><td colspan="4" class="p-4 text-center text-gray-500">No scans yet. Share the QR code with guests!</td></tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
        
        <!-- Export Button -->
        <div class="mt-6 text-center">
            <button onclick="exportData()" class="bg-green-500 text-white px-6 py-2 rounded-lg hover:bg-green-600">
                📥 Export Scan Data (CSV)
            </button>
        </div>
    </div>
    
    <script>
        // Scans over time chart
        const scansData = <?php 
            $dates = [];
            $counts = [];
            while ($row = $scans_by_date->fetch_assoc()) {
                $dates[] = $row['date'];
                $counts[] = $row['count'];
            }
            echo json_encode(['dates' => $dates, 'counts' => $counts]);
        ?>;
        
        if (scansData.dates.length > 0) {
            const ctx = document.getElementById('scansChart').getContext('2d');
            new Chart(ctx, {
                type: 'line',
                data: {
                    labels: scansData.dates,
                    datasets: [{
                        label: 'QR Scans',
                        data: scansData.counts,
                        borderColor: '#ec489a',
                        backgroundColor: 'rgba(236, 72, 153, 0.1)',
                        fill: true
                    }]
                },
                options: { responsive: true }
            });
        }
        
        // Hourly distribution chart
        const hourlyData = <?php
            $hourly = array_fill(0, 24, 0);
            $hour_query = $conn->query("SELECT HOUR(scanned_at) as hour, COUNT(*) as count FROM qr_scans WHERE event_id = $event_id GROUP BY HOUR(scanned_at)");
            while ($row = $hour_query->fetch_assoc()) {
                $hourly[$row['hour']] = $row['count'];
            }
            echo json_encode(array_values($hourly));
        ?>;
        
        const hourlyCtx = document.getElementById('hourlyChart').getContext('2d');
        new Chart(hourlyCtx, {
            type: 'bar',
            data: {
                labels: ['12a','1a','2a','3a','4a','5a','6a','7a','8a','9a','10a','11a','12p','1p','2p','3p','4p','5p','6p','7p','8p','9p','10p','11p'],
                datasets: [{
                    label: 'Scans',
                    data: hourlyData,
                    backgroundColor: '#a855f7'
                }]
            },
            options: { responsive: true }
        });
        
        function exportData() {
            window.location.href = 'export_qr_data.php?id=<?php echo $event_id; ?>';
        }
    </script>
</body>
</html>