<?php if (isAdmin()): ?>
<div class="bg-purple-100 border-b border-purple-200 p-2">
    <div class="container mx-auto">
        <div class="flex gap-3">
            <a href="admin_dashboard.php" class="bg-purple-600 text-white px-4 py-2 rounded hover:bg-purple-700">👑 Admin Dashboard</a>
        </div>
    </div>
</div>
<?php endif; ?>