<?php
ini_set('display_errors', 1);
error_reporting(E_ALL);
require_once '../config.php';
require_once '../auth.php';

// Check if user is admin
if (!isAdmin()) {
    header('Location: ../index.php');
    exit;
}

// Get statistics
$total_events = $conn->query("SELECT COUNT(*) as count FROM events")->fetch_assoc()['count'];
$total_users = $conn->query("SELECT COUNT(*) as count FROM users")->fetch_assoc()['count'];
$total_questions = $conn->query("SELECT COUNT(*) as count FROM questions")->fetch_assoc()['count'];
$total_votes = $conn->query("SELECT COUNT(*) as count FROM votes")->fetch_assoc()['count'];
$total_qr_scans = $conn->query("SELECT SUM(qr_scan_count) as total FROM events")->fetch_assoc()['total'] ?: 0;

// Get recent events
$recent_events = $conn->query("SELECT * FROM events ORDER BY created_at DESC LIMIT 5");

// Get recent users
$recent_users = $conn->query("SELECT * FROM users ORDER BY created_at DESC LIMIT 5");

// Handle delete event
if (isset($_POST['delete_event'])) {
    $event_id = $_POST['event_id'];
    $conn->query("DELETE FROM votes WHERE question_id IN (SELECT id FROM questions WHERE event_id = $event_id)");
    $conn->query("DELETE FROM questions WHERE event_id = $event_id");
    $conn->query("DELETE FROM events WHERE id = $event_id");
    header("Location: admin_dashboard.php?msg=Event deleted");
    exit;
}

// Handle delete user
if (isset($_POST['delete_user'])) {
    $user_id = $_POST['user_id'];
    $conn->query("DELETE FROM users WHERE id = $user_id");
    header("Location: admin_dashboard.php?msg=User deleted");
    exit;
}

// Handle make admin
if (isset($_POST['make_admin'])) {
    $user_id = $_POST['user_id'];
    $conn->query("UPDATE users SET role = 'admin' WHERE id = $user_id");
    header("Location: admin_dashboard.php?msg=User promoted to admin");
    exit;
}

// Handle remove admin
if (isset($_POST['remove_admin'])) {
    $user_id = $_POST['user_id'];
    $conn->query("UPDATE users SET role = 'host' WHERE id = $user_id");
    header("Location: admin_dashboard.php?msg=Admin privileges removed");
    exit;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard - ShadiPulse</title>
    <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
</head>
<body class="bg-gray-100">
    <!-- Navigation -->
    <nav class="bg-purple-700 text-white p-4 shadow-lg">
        <div class="container mx-auto flex justify-between items-center">
            <div>
                <h1 class="text-2xl font-bold">👑 ShadiPulse Admin Dashboard</h1>
                <p class="text-sm opacity-75">Super Admin Control Panel</p>
            </div>
            <div class="flex items-center gap-3">
                <span class="bg-purple-800 px-3 py-1 rounded-full text-sm">
                    👑 <?php echo $_SESSION['full_name']; ?>
                </span>
                <a href="change_password.php" class="bg-yellow-500 text-white px-4 py-2 rounded hover:bg-yellow-600 transition">
                    🔑 Change Password
                </a>
                <a href="../logout.php" class="bg-red-500 px-4 py-2 rounded hover:bg-red-600 transition">Logout</a>
            </div>
        </div>
    </nav>

    <div class="container mx-auto p-6">
        <!-- Alert Messages -->
        <?php if (isset($_GET['msg'])): ?>
            <div class="bg-green-100 border border-green-400 text-green-700 px-4 py-3 rounded mb-4">
                <?php echo htmlspecialchars($_GET['msg']); ?>
            </div>
        <?php endif; ?>

        <!-- Statistics Cards -->
        <div class="grid md:grid-cols-2 lg:grid-cols-5 gap-6 mb-8">
            <div class="bg-gradient-to-r from-blue-500 to-blue-600 rounded-lg shadow p-6 text-white">
                <div class="text-3xl font-bold"><?php echo $total_events; ?></div>
                <div class="text-sm opacity-90">📅 Total Events</div>
            </div>
            <div class="bg-gradient-to-r from-green-500 to-green-600 rounded-lg shadow p-6 text-white">
                <div class="text-3xl font-bold"><?php echo $total_users; ?></div>
                <div class="text-sm opacity-90">👥 Total Users</div>
            </div>
            <div class="bg-gradient-to-r from-yellow-500 to-yellow-600 rounded-lg shadow p-6 text-white">
                <div class="text-3xl font-bold"><?php echo $total_questions; ?></div>
                <div class="text-sm opacity-90">❓ Total Questions</div>
            </div>
            <div class="bg-gradient-to-r from-pink-500 to-pink-600 rounded-lg shadow p-6 text-white">
                <div class="text-3xl font-bold"><?php echo $total_votes; ?></div>
                <div class="text-sm opacity-90">🗳️ Total Votes</div>
            </div>
            <div class="bg-gradient-to-r from-indigo-500 to-indigo-600 rounded-lg shadow p-6 text-white">
                <div class="text-3xl font-bold"><?php echo $total_qr_scans; ?></div>
                <div class="text-sm opacity-90">📊 QR Scans</div>
            </div>
        </div>

        <!-- Quick Actions -->
        <div class="bg-white rounded-lg shadow p-6 mb-8">
            <h2 class="text-2xl font-bold mb-4">⚡ Quick Actions</h2>
            <div class="flex flex-wrap gap-3">
                <a href="create_event.php" class="bg-green-500 text-white px-6 py-3 rounded-lg hover:bg-green-600 transition">
                    ➕ Create New Event
                </a>
                <a href="all_events.php" class="bg-blue-500 text-white px-6 py-3 rounded-lg hover:bg-blue-600 transition">
                    📋 View All Events
                </a>
                <a href="all_users.php" class="bg-purple-500 text-white px-6 py-3 rounded-lg hover:bg-purple-600 transition">
                    👥 Manage Users
                </a>
                <a href="system_settings.php" class="bg-gray-500 text-white px-6 py-3 rounded-lg hover:bg-gray-600 transition">
                    ⚙️ System Settings
                </a>
            </div>
        </div>

        <!-- Recent Events & Users -->
        <div class="grid lg:grid-cols-2 gap-8">
            <!-- Recent Events -->
            <div class="bg-white rounded-lg shadow p-6">
                <h2 class="text-2xl font-bold mb-4 flex justify-between items-center">
                    📅 Recent Events
                    <a href="all_events.php" class="text-sm bg-blue-500 text-white px-3 py-1 rounded">View All</a>
                </h2>
                <div class="space-y-3">
                    <?php if ($recent_events->num_rows == 0): ?>
                        <p class="text-gray-500 text-center py-4">No events created yet.</p>
                    <?php else: ?>
                        <?php while ($event = $recent_events->fetch_assoc()): ?>
                            <div class="border rounded-lg p-4 hover:shadow-md transition">
                                <div class="flex justify-between items-start">
                                    <div class="flex-1">
                                        <h3 class="font-bold text-lg"><?php echo htmlspecialchars($event['name']); ?></h3>
                                        <p class="text-sm text-gray-600">Code: <?php echo $event['event_code']; ?></p>
                                        <p class="text-xs text-gray-500">Created: <?php echo date('M d, Y', strtotime($event['created_at'])); ?></p>
                                    </div>
                                    <div class="flex gap-2">
                                        <a href="event_details.php?id=<?php echo $event['id']; ?>" class="bg-blue-500 text-white px-3 py-1 rounded text-sm">Manage</a>
                                        <form method="POST" onsubmit="return confirm('Delete this event? All data will be lost.')">
                                            <input type="hidden" name="event_id" value="<?php echo $event['id']; ?>">
                                            <button type="submit" name="delete_event" class="bg-red-500 text-white px-3 py-1 rounded text-sm">Delete</button>
                                        </form>
                                    </div>
                                </div>
                            </div>
                        <?php endwhile; ?>
                    <?php endif; ?>
                </div>
            </div>

            <!-- Recent Users -->
            <div class="bg-white rounded-lg shadow p-6">
                <h2 class="text-2xl font-bold mb-4 flex justify-between items-center">
                    👥 Recent Users
                    <a href="all_users.php" class="text-sm bg-purple-500 text-white px-3 py-1 rounded">View All</a>
                </h2>
                <div class="space-y-3">
                    <?php if ($recent_users->num_rows == 0): ?>
                        <p class="text-gray-500 text-center py-4">No users registered yet.</p>
                    <?php else: ?>
                        <?php while ($user = $recent_users->fetch_assoc()): ?>
                            <div class="border rounded-lg p-4 hover:shadow-md transition">
                                <div class="flex justify-between items-start">
                                    <div class="flex-1">
                                        <h3 class="font-bold text-lg"><?php echo htmlspecialchars($user['full_name']); ?></h3>
                                        <p class="text-sm text-gray-600">📧 <?php echo $user['email']; ?></p>
                                        <p class="text-xs">
                                            Role: 
                                            <span class="<?php echo $user['role'] == 'admin' ? 'text-purple-600 font-bold' : 'text-gray-600'; ?>">
                                                <?php echo strtoupper($user['role']); ?>
                                            </span>
                                        </p>
                                    </div>
                                    <div class="flex gap-2">
                                        <?php if ($user['role'] == 'admin'): ?>
                                            <form method="POST" onsubmit="return confirm('Remove admin privileges from this user?')">
                                                <input type="hidden" name="user_id" value="<?php echo $user['id']; ?>">
                                                <button type="submit" name="remove_admin" class="bg-yellow-500 text-white px-3 py-1 rounded text-sm">Remove Admin</button>
                                            </form>
                                        <?php else: ?>
                                            <form method="POST" onsubmit="return confirm('Make this user an admin?')">
                                                <input type="hidden" name="user_id" value="<?php echo $user['id']; ?>">
                                                <button type="submit" name="make_admin" class="bg-green-500 text-white px-3 py-1 rounded text-sm">Make Admin</button>
                                            </form>
                                        <?php endif; ?>
                                        <form method="POST" onsubmit="return confirm('Delete this user? All their events will be lost.')">
                                            <input type="hidden" name="user_id" value="<?php echo $user['id']; ?>">
                                            <button type="submit" name="delete_user" class="bg-red-500 text-white px-3 py-1 rounded text-sm">Delete</button>
                                        </form>
                                    </div>
                                </div>
                            </div>
                        <?php endwhile; ?>
                    <?php endif; ?>
                </div>
            </div>
        </div>

        <!-- System Info -->
        <div class="mt-8 bg-white rounded-lg shadow p-6">
            <h2 class="text-2xl font-bold mb-4">ℹ️ System Information</h2>
            <div class="grid md:grid-cols-2 lg:grid-cols-4 gap-4">
                <div class="border rounded-lg p-3">
                    <p class="text-sm text-gray-600">PHP Version</p>
                    <p class="font-bold"><?php echo phpversion(); ?></p>
                </div>
                <div class="border rounded-lg p-3">
                    <p class="text-sm text-gray-600">MySQL Version</p>
                    <p class="font-bold"><?php echo $conn->server_info; ?></p>
                </div>
                <div class="border rounded-lg p-3">
                    <p class="text-sm text-gray-600">Server Time</p>
                    <p class="font-bold"><?php echo date('Y-m-d H:i:s'); ?></p>
                </div>
                <div class="border rounded-lg p-3">
                    <p class="text-sm text-gray-600">Last Backup</p>
                    <p class="font-bold">Not configured</p>
                </div>
            </div>
        </div>
    </div>
</body>
</html>