-- sql/database.sql
CREATE DATABASE IF NOT EXISTS `shadipulse-3530383528d3`;
USE `shadipulse-3530383528d3`;

-- Users table (Admin & Hosts)
CREATE TABLE `users` (
  `id` int(11) AUTO_INCREMENT PRIMARY KEY,
  `email` varchar(255) UNIQUE NOT NULL,
  `password_hash` varchar(255) NOT NULL,
  `full_name` varchar(255) NOT NULL,
  `role` enum('admin','host') DEFAULT 'host',
  `subscription_plan` enum('free','monthly','yearly','per_event') DEFAULT 'free',
  `subscription_expiry` datetime DEFAULT NULL,
  `created_at` timestamp DEFAULT CURRENT_TIMESTAMP
);

-- Events table
CREATE TABLE `events` (
  `id` int(11) AUTO_INCREMENT PRIMARY KEY,
  `event_code` varchar(20) UNIQUE NOT NULL,
  `name` varchar(255) NOT NULL,
  `event_date` date NOT NULL,
  `created_by` int(11),
  `current_question_id` int(11) DEFAULT NULL,
  `poll_active` tinyint(1) DEFAULT 0,
  `status` enum('upcoming','live','ended') DEFAULT 'upcoming',
  `created_at` timestamp DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (`created_by`) REFERENCES `users`(`id`) ON DELETE CASCADE
);

-- Questions table
CREATE TABLE `questions` (
  `id` int(11) AUTO_INCREMENT PRIMARY KEY,
  `event_id` int(11),
  `question_text` text NOT NULL,
  `question_type` enum('mcq','yesno','emoji') DEFAULT 'mcq',
  `options_json` text, -- JSON array for MCQ options
  `order_index` int(11) DEFAULT 0,
  `is_active` tinyint(1) DEFAULT 1,
  FOREIGN KEY (`event_id`) REFERENCES `events`(`id`) ON DELETE CASCADE
);

-- Votes table
CREATE TABLE `votes` (
  `id` int(11) AUTO_INCREMENT PRIMARY KEY,
  `event_id` int(11),
  `question_id` int(11),
  `option_key` varchar(50),
  `device_id` varchar(255),
  `created_at` timestamp DEFAULT CURRENT_TIMESTAMP,
  UNIQUE KEY `unique_vote` (`question_id`, `device_id`),
  FOREIGN KEY (`event_id`) REFERENCES `events`(`id`) ON DELETE CASCADE,
  FOREIGN KEY (`question_id`) REFERENCES `questions`(`id`) ON DELETE CASCADE
);

-- Reactions table
CREATE TABLE `reactions` (
  `id` int(11) AUTO_INCREMENT PRIMARY KEY,
  `event_id` int(11),
  `reaction_type` varchar(20),
  `device_id` varchar(255),
  `created_at` timestamp DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (`event_id`) REFERENCES `events`(`id`) ON DELETE CASCADE
);

-- Insert default admin
INSERT INTO `users` (`email`, `password_hash`, `full_name`, `role`, `subscription_plan`) 
VALUES ('admin@shadipulse.com', '$2y$10$YourHashHere', 'Super Admin', 'admin', 'monthly');
-- Default password: admin123 (run PHP to generate hash: password_hash('admin123', PASSWORD_DEFAULT))