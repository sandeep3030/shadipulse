<?php
require_once 'config.php';

$event_code = '8BF1788E';

// Get event ID
$stmt = $conn->prepare("SELECT id, current_question_id, poll_active FROM events WHERE event_code = ?");
$stmt->bind_param("s", $event_code);
$stmt->execute();
$event = $stmt->get_result()->fetch_assoc();

echo "<pre>";
echo "Event found: ";
print_r($event);
echo "</pre>";

if ($event && $event['current_question_id']) {
    // Get votes for this question
    $stmt = $conn->prepare("SELECT COUNT(*) as total FROM votes WHERE question_id = ?");
    $stmt->bind_param("i", $event['current_question_id']);
    $stmt->execute();
    $votes = $stmt->get_result()->fetch_assoc();
    
    echo "<p>Total votes for question {$event['current_question_id']}: " . $votes['total'] . "</p>";
    
    // Get all votes
    $result = $conn->query("SELECT * FROM votes");
    echo "<p>All votes in database: " . $result->num_rows . "</p>";
    
    while ($row = $result->fetch_assoc()) {
        echo "Vote: " . print_r($row, true) . "<br>";
    }
} else {
    echo "<p>No active poll or no current question set.</p>";
}

// Check if there's any data at all
$result = $conn->query("SELECT COUNT(*) as cnt FROM events");
$events_count = $result->fetch_assoc()['cnt'];
echo "<p>Total events: $events_count</p>";

$result = $conn->query("SELECT COUNT(*) as cnt FROM questions");
$questions_count = $result->fetch_assoc()['cnt'];
echo "<p>Total questions: $questions_count</p>";

$result = $conn->query("SELECT COUNT(*) as cnt FROM votes");
$votes_count = $result->fetch_assoc()['cnt'];
echo "<p>Total votes: $votes_count</p>";
?>