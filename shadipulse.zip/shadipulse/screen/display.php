<?php
require_once '../config.php';

$event_code = $_GET['code'] ?? '';
if (empty($event_code)) {
    die("Invalid event code");
}

// Get event ID
$stmt = $conn->prepare("SELECT id FROM events WHERE event_code = ?");
$stmt->bind_param("s", $event_code);
$stmt->execute();
$event = $stmt->get_result()->fetch_assoc();

if (!$event) {
    die("Event not found");
}

$event_id = $event['id'];
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>ShadiPulse - Live Display</title>
    <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css" rel="stylesheet">
    <style>
        .floating-emoji {
            position: fixed;
            font-size: 3rem;
            pointer-events: none;
            animation: floatUp 3s ease-out forwards;
            z-index: 1000;
        }
        @keyframes floatUp {
            0% { transform: translateY(0) scale(1); opacity: 1; }
            100% { transform: translateY(-300px) scale(1.5); opacity: 0; }
        }
        .vote-count {
            transition: all 0.5s ease;
        }
    </style>
</head>
<body class="bg-gradient-to-br from-purple-900 to-pink-800 min-h-screen">
    <div class="container mx-auto px-4 py-8">
        <h1 class="text-5xl font-bold text-center text-white mb-8">🎊 Live Wedding Poll 🎊</h1>
        
        <div id="question-display" class="bg-white rounded-3xl shadow-2xl p-8 mb-8 text-center">
            <h2 id="question-text" class="text-4xl font-bold text-gray-800">Waiting for poll to start...</h2>
        </div>
        
        <div class="grid md:grid-cols-2 gap-8">
            <div class="bg-white rounded-3xl shadow-2xl p-6">
                <h3 class="text-2xl font-bold mb-4 text-center">📊 Live Results</h3>
                <canvas id="resultsChart" height="300"></canvas>
            </div>
            
            <div class="bg-white rounded-3xl shadow-2xl p-6">
                <h3 class="text-2xl font-bold mb-4 text-center">💝 Engagement Stats</h3>
                <div class="text-center">
                    <p class="text-6xl font-bold text-pink-600" id="totalVotes">0</p>
                    <p class="text-gray-600 text-lg mt-2">Total Votes</p>
                    <hr class="my-4">
                    <p class="text-4xl font-bold text-purple-600 mt-4" id="totalParticipants">0</p>
                    <p class="text-gray-600 text-lg">Active Participants</p>
                </div>
            </div>
        </div>
        
        <div class="mt-8 text-center text-white text-sm">
            <p>🎉 Scan QR code to vote from your phone 🎉</p>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/canvas-confetti@1"></script>
    <script>
        const eventCode = '<?php echo $event_code; ?>';
        let resultsChart = null;
        let lastVoteCount = 0;
        let lastReactionCount = 0;
        
        async function fetchDisplayData() {
            try {
                const response = await fetch(`../api/screen_api.php?event_code=${eventCode}`);
                const data = await response.json();
                
                if (data.success) {
                    // Update question
                    if (data.question) {
                        document.getElementById('question-text').innerText = data.question;
                    } else {
                        document.getElementById('question-text').innerText = '💝 Get ready to vote! 💝';
                    }
                    
                    // Update results chart
                    if (data.results && data.results.length > 0) {
                        updateChart(data.results);
                        const total = data.results.reduce((sum, r) => sum + r.count, 0);
                        document.getElementById('totalVotes').innerText = total;
                        
                        // Confetti on milestone (every 10 votes)
                        if (total > 0 && total % 10 === 0 && total !== lastVoteCount) {
                            canvasConfetti({ 
                                particleCount: 150, 
                                spread: 70, 
                                origin: { y: 0.6 },
                                colors: ['#ec489a', '#a855f7', '#fbbf24']
                            });
                        }
                        lastVoteCount = total;
                    }
                    
                    // Update participants
                    if (data.total_participants) {
                        document.getElementById('totalParticipants').innerText = data.total_participants;
                    }
                    
                    // Show floating emoji reactions
                    if (data.reactions && data.reactions.length > 0 && data.reactions.length !== lastReactionCount) {
                        data.reactions.forEach(reaction => {
                            showFloatingEmoji(reaction.reaction_type);
                        });
                        lastReactionCount = data.reactions.length;
                    }
                }
            } catch (error) {
                console.error('Error fetching data:', error);
            }
        }
        
        function updateChart(results) {
            const labels = results.map(r => r.label);
            const counts = results.map(r => r.count);
            
            if (resultsChart) {
                resultsChart.data.datasets[0].data = counts;
                resultsChart.update();
            } else {
                const ctx = document.getElementById('resultsChart').getContext('2d');
                resultsChart = new Chart(ctx, {
                    type: 'pie',
                    data: { 
                        labels: labels, 
                        datasets: [{ 
                            data: counts, 
                            backgroundColor: ['#f472b6', '#c084fc', '#60a5fa', '#34d399', '#fbbf24', '#f97316'],
                            borderWidth: 2,
                            borderColor: '#fff'
                        }] 
                    },
                    options: { 
                        responsive: true, 
                        maintainAspectRatio: true,
                        plugins: { 
                            legend: { position: 'bottom', labels: { font: { size: 14 } } },
                            tooltip: { bodyFont: { size: 14 } }
                        }
                    }
                });
            }
        }
        
        function showFloatingEmoji(emoji) {
            const div = document.createElement('div');
            div.className = 'floating-emoji';
            div.innerText = emoji;
            div.style.left = Math.random() * window.innerWidth + 'px';
            div.style.bottom = '20px';
            document.body.appendChild(div);
            setTimeout(() => div.remove(), 3000);
        }
        
        // Initial load
        fetchDisplayData();
        // Refresh every 2 seconds
        setInterval(fetchDisplayData, 2000);
    </script>
</body>
</html>