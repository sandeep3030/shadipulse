<?php
require_once 'config.php';

$event_code = $_GET['code'] ?? '';
$scan_token = $_GET['token'] ?? '';

if (empty($event_code)) {
    die("Invalid QR code");
}

// Get event ID
$stmt = $conn->prepare("SELECT id FROM events WHERE event_code = ?");
$stmt->bind_param("s", $event_code);
$stmt->execute();
$event = $stmt->get_result()->fetch_assoc();

if ($event) {
    // Generate scan token if not provided (first scan)
    if (empty($scan_token)) {
        $scan_token = md5(uniqid() . $event_code . time());
    }
    
    // Record the scan
    $ip = $_SERVER['REMOTE_ADDR'] ?? '';
    $user_agent = $_SERVER['HTTP_USER_AGENT'] ?? '';
    
    $stmt = $conn->prepare("INSERT INTO qr_scans (event_id, scan_token, ip_address, user_agent) VALUES (?, ?, ?, ?)");
    $stmt->bind_param("isss", $event['id'], $scan_token, $ip, $user_agent);
    $stmt->execute();
    
    // Update scan count in events table
    $conn->query("UPDATE events SET qr_scan_count = qr_scan_count + 1 WHERE id = " . $event['id']);
}

// Redirect to actual guest voting page
header("Location: guest/vote.php?code=" . $event_code);
exit;
?>