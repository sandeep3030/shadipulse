<?php
// File Structure Checker for ShadiPulse
echo "<!DOCTYPE html>
<html>
<head>
    <title>ShadiPulse - File Structure Check</title>
    <style>
        body { font-family: monospace; background: #f4f4f4; padding: 20px; }
        .container { max-width: 800px; margin: auto; background: white; padding: 20px; border-radius: 10px; }
        h1 { color: #ec489a; }
        .status-ok { color: green; font-weight: bold; }
        .status-missing { color: red; font-weight: bold; }
        .status-warning { color: orange; }
        ul { list-style: none; padding-left: 0; }
        li { margin: 5px 0; }
        .folder { background: #f0f0f0; padding: 10px; margin-top: 15px; border-left: 4px solid #ec489a; }
    </style>
</head>
<body>
<div class='container'>
    <h1>🎉 ShadiPulse - File Structure Checker</h1>";

$baseDir = __DIR__;
echo "<p>Checking directory: <code>$baseDir</code></p>";

$requiredFiles = [
    // Root files
    'index.php' => 'root',
    'config.php' => 'root',
    'auth.php' => 'root',
    
    // Directories (must exist)
    'guest/' => 'dir',
    'host/' => 'dir',
    'screen/' => 'dir',
    'api/' => 'dir',
    
    // Guest files
    'guest/vote.php' => 'file',
    
    // Host files
    'host/dashboard.php' => 'file',
    'host/event_details.php' => 'file',
    'host/create_event.php' => 'file',
    
    // Screen files
    'screen/display.php' => 'file',
    
    // API files
    'api/guest_api.php' => 'file',
    'api/host_api.php' => 'file',
    'api/screen_api.php' => 'file',
];

$optionalFiles = [
    'host/event_details.php' => 'Required for event management',
    'host/create_event.php' => 'Required for event creation',
];

$results = ['ok' => [], 'missing' => [], 'dir_missing' => []];

foreach ($requiredFiles as $path => $type) {
    $fullPath = $baseDir . '/' . $path;
    if ($type === 'dir') {
        if (is_dir($fullPath)) {
            $results['ok'][] = $path . '/ (directory exists)';
        } else {
            $results['dir_missing'][] = $path . '/ (directory missing)';
        }
    } else { // file
        if (file_exists($fullPath) && is_file($fullPath)) {
            // Check if file is not empty (optional)
            $size = filesize($fullPath);
            $status = ($size > 0) ? "✅ ($size bytes)" : "⚠️ (file is empty)";
            $results['ok'][] = "$path $status";
        } else {
            $results['missing'][] = $path . " (file missing)";
        }
    }
}

// Also check for any extra PHP files in root that might be misplaced
$allRootPhp = glob($baseDir . '/*.php');
$expectedRootPhp = ['index.php', 'config.php', 'auth.php', 'check_structure.php']; // ignore this script
$unexpected = array_diff($allRootPhp, array_map(function($f) use ($baseDir) { return $baseDir . '/' . $f; }, $expectedRootPhp));
$unexpected = array_map('basename', $unexpected);

// Output results
echo "<div class='folder'>📁 Root Directory</div>";
echo "<ul>";
foreach ($results['ok'] as $ok) {
    if (strpos($ok, 'empty') !== false) {
        echo "<li><span class='status-warning'>⚠️</span> $ok</li>";
    } else {
        echo "<li><span class='status-ok'>✅</span> $ok</li>";
    }
}
foreach ($results['missing'] as $missing) {
    echo "<li><span class='status-missing'>❌</span> $missing</li>";
}
foreach ($results['dir_missing'] as $dirMissing) {
    echo "<li><span class='status-missing'>❌</span> $dirMissing</li>";
}
if (!empty($unexpected)) {
    echo "<li><span class='status-warning'>⚠️</span> Unexpected PHP files in root: " . implode(', ', $unexpected) . "</li>";
}
echo "</ul>";

if (empty($results['missing']) && empty($results['dir_missing'])) {
    echo "<p style='color:green; font-weight:bold;'>🎉 All required files and directories are present!</p>";
} else {
    echo "<p style='color:red; font-weight:bold;'>⚠️ Some files/directories are missing. Please upload them.</p>";
}

// Check config.php DB connection (optional)
if (file_exists($baseDir . '/config.php')) {
    echo "<div class='folder'>🔌 Database Connection Test</div>";
    try {
        include $baseDir . '/config.php';
        if ($conn && $conn->ping()) {
            echo "<p><span class='status-ok'>✅</span> Database connection successful.</p>";
            // Check users table
            $res = $conn->query("SELECT COUNT(*) as count FROM users");
            if ($res) {
                $row = $res->fetch_assoc();
                echo "<p><span class='status-ok'>✅</span> 'users' table exists with {$row['count']} records.</p>";
            } else {
                echo "<p><span class='status-missing'>❌</span> 'users' table missing. Please import database.sql.</p>";
            }
        } else {
            echo "<p><span class='status-missing'>❌</span> Database connection failed. Check config.php credentials.</p>";
        }
    } catch (Exception $e) {
        echo "<p><span class='status-missing'>❌</span> Database error: " . $e->getMessage() . "</p>";
    }
}

echo "</div></body></html>";
?>